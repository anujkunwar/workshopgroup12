from django.db import models

# Create your models here.
room_category = (
    ("Single Bedroom", "Single Bedroom"),
    ("Double bedroom", "Double bedroom"),
    ("Luxery Room", "Luxery Room"),
    
)
# Create your models here.
room_availability = (
    ("Available", "Available"),
    ("Packed", "Packed"),
)
class HotelDetails(models.Model):
    hotelImagge =  models.ImageField(upload_to='images/')
    roomType = models.CharField(max_length=100, choices=room_category, default="Single Bedroom")
    availability = models.CharField(max_length=100, choices=room_availability, default="Available")
    price = models.CharField(max_length=100)