from django.http import HttpResponse
from django.shortcuts import render, redirect
from .form import HotelForm

# Create your views here.
def uploadPic(request):

	if request.method == 'POST':
		form = HotelForm(request.POST, request.FILES)

		if form.is_valid():
			form.save()
			return redirect('success')
	else:
		form = HotelForm()
	return render(request, 'home.html', {'form' : form})


def success(request):
	return HttpResponse('successfully uploaded')
