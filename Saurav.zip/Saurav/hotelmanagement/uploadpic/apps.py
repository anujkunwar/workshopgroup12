from django.apps import AppConfig


class UploadpicConfig(AppConfig):
    name = 'uploadpic'
