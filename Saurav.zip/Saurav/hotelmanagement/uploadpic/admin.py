from django.contrib import admin
from .models import HotelDetails
# Register your models here.
admin.site.register(HotelDetails)